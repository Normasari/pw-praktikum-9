<?php
require 'function.php';

$karyawan = query("SELECT * FROM karyawan");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 9</title>
</head>

<body>
    <div style="text-align: center;">
    <h1 style="padding: 20px; background:  #A9A9A9;">PT.Cendikia Raya</h1><br>
    <img src="logo.png" alt="" width="400">
        
        <br><br>
        <h2 style="background: #A9A9A9; margin-left:30%; margin-right:30%; border: 12px;">Daftar Karyawan</h2>

        <table border="1" align="center" cellpadding="10" cellspacing="0">
            <tr style="background: #A9A9A9;">
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Gender</th>
                <th>Position</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php foreach ($karyawan as $data) : ?>
                <tr style="background: #7FFFD4;">
                    <td><?= $data['id']; ?></td>
                    <td><?= $data['name']; ?></td>
                    <td><?= $data['email']; ?></td>
                    <td><?= $data['address']; ?></td>
                    <td><?= $data['gender']; ?></td>
                    <td><?= $data['position']; ?></td>
                    <td><?= $data['status']; ?></td>
                    <td><a href="hapus.php?id=<?= $data['id']; ?>" class="btn btn-danger" onclick="return confirm('Data akan dihapus, apakah anda yakin ?')">Delete</a></td>
                </tr>
            <?php endforeach ?>
        </table>
        <br>
        <div class="flex-container">
            <a href="tambah.php" class="btn btn-primary" style="margin:right;">Add Data</a>
        </div>
        <br>
    </div>
</body>

</html>